
import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Filter, X, Upload, Download, Settings2, PlugZap, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";

const defaultPresets = {
  BASIC: [
    { combo: "M", description: "Move" },
    { combo: "Ctrl+Z", description: "Undo" },
    { combo: "Ctrl+Y", description: "Redo" },
  ],
};

const createEmptyGrid = () => Array(3).fill().map(() => Array(3).fill({ tap: null, hold: null }));

const AnimatedModalWrapper = ({ children, show }) => (
  <AnimatePresence>
    {show && (
      <motion.div
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
      >
        <motion.div
          className="bg-zinc-800 p-6 rounded-lg shadow-xl border border-red-500 max-w-md w-full"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

const CategoryFAB = ({ current, setCurrent, categories }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="fixed bottom-6 right-6 z-50">
      {open && (
        <motion.div
          className="mb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
        >
          <Select value={current} onValueChange={setCurrent}>
            <SelectTrigger className="w-48 bg-zinc-900 border-red-500 text-white">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 text-white">
              {Object.keys(categories).map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>
      )}
      <Button className="rounded-full p-3 bg-red-600 hover:bg-red-700 shadow-lg" onClick={() => setOpen(prev => !prev)}>
        {open ? <X className="w-5 h-5" /> : <Filter className="w-5 h-5" />}
      </Button>
    </div>
  );
};

export default function App() {
  const [keymap, setKeymap] = useState(createEmptyGrid());
  const [port, setPort] = useState(null);
  const [writer, setWriter] = useState(null);
  const [serialConnected, setSerialConnected] = useState(false);
  const [currentCategory, setCurrentCategory] = useState("BASIC");
  const [showModal, setShowModal] = useState(false);
  const [selectedCell, setSelectedCell] = useState(null);
  const [shortcutPool, setShortcutPool] = useState(defaultPresets);

  const connectSerial = async () => {
    try {
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
      const writer = port.writable.getWriter();
      setPort(port);
      setWriter(writer);
      setSerialConnected(true);
    } catch (err) {
      alert("Connection failed: " + err.message);
    }
  };

  const sendToSerial = async (data) => {
    if (writer) {
      await writer.write(new TextEncoder().encode(data + "\n"));
    }
  };

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(keymap)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "mapping.json";
    a.click();
  };

  const handleImport = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        setKeymap(data);
      } catch (err) {
        alert("Invalid JSON file.");
      }
    };
    reader.readAsText(file);
  };

  const handleUpload = () => {
    if (!writer) return alert("Not connected to device.");
    const payload = JSON.stringify(keymap);
    sendToSerial("SETUP:" + payload);
  };

  const openMappingModal = (row, col) => {
    setSelectedCell({ row, col });
    setShowModal(true);
  };

  const assignMapping = (mapping) => {
    const newGrid = [...keymap];
    newGrid[selectedCell.row][selectedCell.col] = mapping;
    setKeymap(newGrid);
    setShowModal(false);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white p-6">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">TRKey Configurator</h1>
        <div className="flex gap-2">
          <Button className="bg-red-600 hover:bg-red-700" onClick={handleUpload}>
            <Upload className="mr-2 w-4 h-4" /> Upload to Pad
          </Button>
          <Button className="bg-red-600 hover:bg-red-700" onClick={handleExport}>
            <Download className="mr-2 w-4 h-4" /> Export
          </Button>
          <label className="bg-zinc-700 hover:bg-zinc-800 cursor-pointer px-4 py-2 rounded flex items-center gap-2">
            <Download className="w-4 h-4" /> Import
            <input type="file" className="hidden" accept=".json" onChange={handleImport} />
          </label>
          <Button className="bg-green-600 hover:bg-green-700" onClick={connectSerial}>
            <PlugZap className="mr-2 w-4 h-4" /> {serialConnected ? "Connected" : "Connect"}
          </Button>
        </div>
      </header>

      <main>
        <p className="mb-4">Shortcut Category: <span className="text-red-400 font-semibold">{currentCategory}</span></p>
        <div className="grid grid-cols-3 gap-4">
          {keymap.map((row, rIdx) =>
            row.map((cell, cIdx) => (
              <div key={\`\${rIdx}-\${cIdx}\`} className="p-4 bg-red-500 rounded-lg text-black hover:shadow-md cursor-pointer" onClick={() => openMappingModal(rIdx, cIdx)}>
                <div className="font-bold text-base">{cell.tap?.description || "Tap: -"} </div>
                <div className="text-sm opacity-70">{cell.tap?.combo || ""}</div>
                <div className="mt-1 font-bold text-base">{cell.hold?.description || "Hold: -"} </div>
                <div className="text-sm opacity-70">{cell.hold?.combo || ""}</div>
              </div>
            ))
          )}
        </div>
      </main>

      <AnimatedModalWrapper show={showModal}>
        <div>
          <h2 className="text-xl text-red-300 font-bold mb-4">Assign Shortcut</h2>
          <div className="grid grid-cols-2 gap-2">
            {shortcutPool[currentCategory]?.map((item, idx) => (
              <div key={idx} className="bg-red-600 text-black p-2 rounded cursor-pointer" onClick={() => assignMapping({ tap: item, hold: null })}>
                <div>{item.description}</div>
                <div className="text-xs">{item.combo}</div>
              </div>
            ))}
          </div>
          <div className="text-right mt-4">
            <Button onClick={() => setShowModal(false)}>Cancel</Button>
          </div>
        </div>
      </AnimatedModalWrapper>

      <CategoryFAB current={currentCategory} setCurrent={setCurrentCategory} categories={shortcutPool} />
    </div>
  );
}
